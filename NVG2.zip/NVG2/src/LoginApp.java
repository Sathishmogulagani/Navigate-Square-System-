import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class LoginApp extends JFrame {
    public LoginApp() {


       
        JFrame frame;
        frame= new JFrame(); 
        frame.setTitle("navigatesquare.com");
        ImageIcon logo=new ImageIcon("roar.jpg");
        frame.setIconImage(logo.getImage());
        frame.getContentPane().setBackground(new Color(143,143,143));
        frame.setLocationRelativeTo(null);

        JLabel headingLabel = new JLabel("<html><b><h1 style='color:grey;'>Welcome to Navigate² !!</h1><b></html>");
        headingLabel.setFont(new Font("Arial", Font.ROMAN_BASELINE, 20));
        headingLabel.setBounds(200,10, 979, 60); 
        headingLabel.setHorizontalAlignment(SwingConstants.CENTER);

        frame.add(headingLabel);


    //collage Logo
    ImageIcon clglogo=new ImageIcon("qr-code-icon.png");
    Image iclglogo=clglogo.getImage();
    Image resizedImg=iclglogo.getScaledInstance(150,150,Image.SCALE_SMOOTH);
    ImageIcon reclglogo=new ImageIcon(resizedImg);
    JLabel img=new JLabel(reclglogo);
    //img.setBorder(BorderFactory.createLineBorder(Color.BLACK,3));


    img.setBounds(500,150,150,150);
    frame.getContentPane().add(img);

    //collage Logo
    ImageIcon clglogo1=new ImageIcon("camera-icon.png");
    Image iclglogo1=clglogo1.getImage();
    Image resizedImg1=iclglogo1.getScaledInstance(150,150,Image.SCALE_SMOOTH);
    ImageIcon reclglogo1=new ImageIcon(resizedImg1);
    JLabel img1=new JLabel(reclglogo1);
    //img.setBorder(BorderFactory.createLineBorder(Color.BLACK,3));


    img1.setBounds(900,150,150,150);
    frame.getContentPane().add(img1);




        frame.revalidate();
        frame.repaint();


        //frame defalut functionalities
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setSize(screenSize);
        frame.setLayout(null);
        frame.setVisible(true);

    }

    public static void main(String[] args)  throws IOException, InterruptedException
     {
        SwingUtilities.invokeLater(() -> {
        

        try{
            while(true)
            {
                String user=JOptionPane.showInputDialog(null, "<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Enter user id:</h></b></html>","Navigate²",JOptionPane.OK_CANCEL_OPTION);
                if(user.equals("nvgt@12")){
                        String psw=JOptionPane.showInputDialog(null, "<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Enter Password:</h></b></html>","Navigate²",JOptionPane.OK_CANCEL_OPTION);
                        if(psw==null) break;
                        else if(psw.equals("123456"))
                        {
                            JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Welcome User!!</h></b></html>","Navigate²",JOptionPane.INFORMATION_MESSAGE);
                            new LoginApp().setVisible(true);
                            break;
                        }
                        else{JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Incorrect Password</h></b></html>","Navigate²",JOptionPane.ERROR_MESSAGE);}
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Incorrect Username</h></b></html>","Navigate²",JOptionPane.ERROR_MESSAGE);

                }
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,"<html><b><h4 style='color:grey;font-family:Comic Sans MS;'>Sorry we cannot assist you now!!</h></b></html>","Navigate²",JOptionPane.INFORMATION_MESSAGE);
        }
    });
        }
    }

